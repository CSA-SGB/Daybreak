'''
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>
'''

'''
Samantha Bennefield
4/7/17
Mr. Davis
Daybreak (Top-down dungeon crawler)
Version 2
'''


'''
Notes:
HP  = Health Points
ATK = Attack Damage

-Current goal is to get at least one level working, after that other levels
    (with the exception of the boss fight) are just a matter of copying code

-Player/Enemy/Boss Health and Attack are probably unbalanced
-Start screen needs to be changed
-Cat sprite needs to be replaced
-Enemies are currently a square, this needs to be replaced
-An enemy spawns and currently just runs off screen. I'm trying to fix this.
-Sprite art is getting done but probably won't be added until the basic game mechanics are working
-Player still can't move left & right
-No combat system yet
-No boss yet
'''

import pygame
import sys
import random

pygame.init()

WIDTH = 400
HEIGHT = 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))

pygame.display.set_caption("Daybreak v2")


clock = pygame.time.Clock() #<--This isn't being used right now


#Sprites
player_sprite = pygame.image.load('cat.png') #<--PLACEHOLDER


#The Hallway Image
#-To explain the current hallway the black lines are walls and the red lines are doors
hallway = pygame.image.load('temp_hallway.png')

#Hallway Boundaries
#-(Temporary?) Boundaries for collision
hallway_top = 700
hallway_bottom = 0
hallway_right = 350
hallway_left = 50


#Colors
WHITE = (255, 255, 255)
BLACK = (0,   0,   0)
RED   = (255, 0,   0)


#Font
myfont=pygame.font.SysFont("Britannic Bold", 40) #<--PLACEHOLDER


#Entity Class
class Entity(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        pygame.sprite.Sprite.__init__(self)

        self.x = x
        self.y = y
        self.width = width
        self.height = height

        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)


#Character Class
class Character(Entity):
    def __init__(self, x, y, width, height):
        super(Character, self).__init__(x, y, width, height)

        self.image = player_sprite


#Player Class
class Player(Character):
    def __init__(self, x, y, width, height, hp, atk):
        super(Player, self).__init__(x, y, width, height)

        self.hp = hp
        self.atk = atk

        self.x_change = 0
        self.x_dist = 1

        self.y_change = 0
        self.y_dist = 1

    def MoveKeyDown(self, key): #Any key is pressed
        if (key == pygame.K_w):
            self.y_change += -self.y_dist
            self.y = self.y + self.y_change
            print(self.y)
        elif (key == pygame.K_s):
            self.y_change += self.y_dist
            self.y = self.y + self.y_change
            print(self.y)
        elif (key == pygame.K_d):
            self.x_change += -self.x_dist
            self.x = self.x + self.x_change
            print(self.x)
        elif (key == pygame.K_a):
            self.x_change += self.x_dist
            self.x = self.x + self.x_change
            print(self.x)
        elif (key == pygame.K_SPACE): #Attack
            print("attacking")

    def MoveKeyUp(self, key): #After a key is pressed
        if (key == pygame.K_w):
            self.y_change += self.y_dist
            print(self.y)
        elif (key == pygame.K_s):
            self.y_change += -self.y_dist
            print(self.y)
        elif (key == pygame.K_d):
            self.x_change += self.x_dist
            print(self.x)
        elif (key == pygame.K_a):
            self.x_change += -self.x_dist
            print(self.x)

    def update(self):
        self.rect.move_ip(0, self.x_change)
        self.rect.move_ip(0, self.y_change)

        if self.rect.y < 0:
            self.rect.y = 0
        elif self.rect.y > hallway_top - self.height:
            self.rect.y = hallway_top - self.height

        if self.rect.x < hallway_left:
            self.rect.x = hallway_left
        elif self.rect.x > hallway_right - self.width:
            self.rect.x = hallway_right - self.width


#Enemy Class
class Enemy(Entity):
    def __init__(self, x, y, width, height, hp, atk):
        super(Enemy, self).__init__(x, y, width, height)

        self.hp = hp
        self.atk = atk

        self.x_change = 0
        self.x_dist = 1

        self.y_change = 0
        self.y_dist = 1

        self.image = pygame.Surface([width, height])
        self.image.fill(RED)

    def Move(self):
        direction = random.randint(1, 4)
        if (direction==1):
            self.y_change += -self.y_dist
            self.y = self.y + self.y_change
            print(self.y)
        elif (direction==2):
            self.y_change += self.y_dist
            self.y = self.y + self.y_change
            print(self.y)
        elif (direction==3):
            self.x_change += -self.x_dist
            self.x = self.x + self.x_change
            print(self.x)
        elif (direction==4):
            self.x_change += self.x_dist
            self.x = self.x + self.x_change
            print(self.x)

    def update(self):
        self.rect.move_ip(0, self.x_change)
        self.rect.move_ip(0, self.y_change)

        if self.rect.y < 0:
            self.rect.y = 0
        elif self.rect.y > hallway_top - self.height:
            self.rect.y = hallway_top - self.height

        if self.rect.x < hallway_left:
            self.rect.x = hallway_left
        elif self.rect.x > hallway_right - self.width:
            self.rect.x = hallway_right - self.width




#Boss Enemy Class
class BossEnemy(Entity):
    def __init__(self, x, y, width, height, hp, atk):
        super(BossEnemy, self).__init__(x, y, width, height, hp, atk)

        self.hp = 200
        self.atk = 20

        self.x_change = 0
        self.x_dist = 1

        self.y_change = 0
        self.y_dist = 1

        self.image = pygame.Surface([width, height])
        self.image.fill(WHITE)

    def move(self):
        direction = random.randint(1, 4)
        if direction == 1: #Move up
            self.y_change += -self.y_dist
        elif direction == 2: #Move down
            self.y_change += self.y_dist
        elif direction == 3: #Move right
            self.x_change += -self.x_dist
        elif direction == 4: #Move left
            self.x_change += self.x_dist


        '''self.x_direction = 5
        self.y_direction = 5'''

        self.speed = 2

    def update(self):
        self.rect.x-=self.speed


player = Player(WIDTH/2, HEIGHT/2, 20, 50, 100, 10)
first = Enemy(100, HEIGHT/2, 20, 20, 50, 5) #Temporary enemy

all_sprites_list = pygame.sprite.Group()
all_sprites_list.add(player)
all_sprites_list.add(first)


#Start Screen
#-Needs to be changed
end_it=False
while (end_it==False):
    screen.fill(BLACK)

    #Text for Start Screen
    label  = myfont.render("Start Screen", 1, (WHITE))
    label2 = myfont.render("(Click to continue)", 1, (WHITE))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type==pygame.MOUSEBUTTONDOWN:
            end_it=True

    #Bliting start screen text
    screen.blit(label,(110,200))
    screen.blit(label2, (70, 230))
    pygame.display.flip()


#Instructions Screen
#-If left/right aren't working in the final take them off of here
end_it2=False
while (end_it2==False):
    screen.fill(BLACK)

    #Text for Instructions Screen
    instruction  = myfont.render("Instructions:", 1, (WHITE))
    instruction2 = myfont.render("W = Move up", 1, (WHITE))
    instruction3 = myfont.render("A = Move left", 1, (WHITE))
    instruction4 = myfont.render("S = Move down", 1, (WHITE))
    instruction5 = myfont.render("D = Move right", 1, (WHITE))
    instruction6 = myfont.render("SPACE BAR = Attack", 1, (WHITE))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            end_it2 = True

    #Bliting all instructions text
    screen.blit(instruction, (100, 150))
    screen.blit(instruction2, (100, 200))
    screen.blit(instruction3, (100, 230))
    screen.blit(instruction4, (100, 260))
    screen.blit(instruction5, (100, 290))
    screen.blit(instruction6, (50, 320))
    pygame.display.flip()


end_lvl1 = False
while (end_lvl1==False):
    screen.fill(BLACK)
    screen.blit(hallway, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type==pygame.KEYDOWN:
            if player.rect.y >= hallway_top:
                print("moving to lvl2")
                end_lvl1 = True
            else:
                print("key down in lvl 1")
                player.MoveKeyDown(event.key)
                Enemy.Move()
        elif event.type==pygame.KEYUP:
            player.MoveKeyUp(event.key)

    for ent in all_sprites_list:
        ent.update()

    all_sprites_list.draw(screen)

    pygame.display.flip()


#Game Loop
while True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type==pygame.KEYDOWN:
            print("key down")
            player.MoveKeyDown(event.key)
        elif event.type==pygame.KEYUP:
            player.MoveKeyUp(event.key)

    screen.fill(BLACK)

    for ent in all_sprites_list:
        ent.update()

    all_sprites_list.draw(screen)

    pygame.display.flip()